package com.cts.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.product.bean.Login;
import com.cts.product.service.LoginService;

@Controller

public class LoginController {
	
	@RequestMapping("login.html")
	public String getLoginPage(){
		return "login";
	}
	
	@Autowired
	@Qualifier("loginService")
	LoginService loginService;
	@RequestMapping(value = "login.html", method = RequestMethod.POST)
	public ModelAndView validateUser(@ModelAttribute Login login){
		ModelAndView modelAndView = new ModelAndView();
		Login login2 = loginService.authenticate(login.getUserName(), login.getPassword());
		System.out.println(login2.getUserName()+" "+login2.getPassword());
		if(loginService.authenticate(login.getUserName(), login.getPassword()) != null)
		{
			modelAndView.setViewName("admin");
		}
		else
		{
			modelAndView.setViewName("login");
		}
		return modelAndView;
	}
	
}
