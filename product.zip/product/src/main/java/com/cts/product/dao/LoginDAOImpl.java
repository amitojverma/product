package com.cts.product.dao;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.product.bean.Login;
@Repository("loginDAO")
public class LoginDAOImpl implements LoginDAO{
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	
	@Transactional(readOnly=true)
	public Login authenticate(String userName, String password) {
		String query = "from Login where userName = ? AND password = ?";
		Session session = null;
		org.hibernate.query.Query<Login> query2 = null;
		try {
			session = sessionFactory.getCurrentSession();
			query2 = session.createQuery(query);
			query2.setParameter(0, userName);
			query2.setParameter(1, password);
			Login login = query2.getSingleResult();
			if(login == null)
				return null;
			return login;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			
		}
		
		return null;
	}

}
